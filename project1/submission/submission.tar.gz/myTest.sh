#!/bin/bash

./compile.sh && ./runTestharness.sh && ./runTestharness.sh && ./runTestharness.sh && ./runTestharness.sh && ./runTestharness.sh